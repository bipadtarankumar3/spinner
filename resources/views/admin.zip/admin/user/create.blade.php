@extends('adminLayouts.home')
@section('content')

<div class="container-fluid">

    <div class="card bg-light-info shadow-none position-relative overflow-hidden">
        <div class="card-body px-4 py-3">
          <div class="row align-items-center">
            <div class="col-9">
              <h4 class="fw-semibold mb-8">Create User</h4>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a class="text-muted text-decoration-none" href="index.html">User</a></li>
                  <li class="breadcrumb-item" aria-current="page">Create User</li>
                </ol>
              </nav>
            </div>
            <div class="col-3">
              <div class="text-center mb-n5">  
                <img src="{{asset('adminAssets/images/breadcrumb/ChatBc.png')}}" alt="" class="img-fluid mb-n4">
              </div>
            </div>
          </div>
        </div>
      </div>

    <!-- basic table -->
    <div class="row">
        <div class="col-md-12">
          
          <div class="card w-100">
            <div class="card-header">
              <h5>Create User </h5>
            </div>
            <form method="POST" action="{{URL::to('admin/add_sub_user')}}"  enctype="multipart/form-data">
              @csrf
              <input type="hidden" name="id" @if (isset($user)) value="{{$user->id}}"  @endif>
              

              <div class="card-body border-top">
                <h5>Personal Info</h5>
                <div class="row">
                  <div class="col-sm-12 col-md-4">
                    <div class="mb-3">
                      <label for="name_url" class="control-label col-form-label">User Url</label>
                      <input type="text" name="name_url"  @if (isset($user)) value="{{$user->name_url}}"  @endif class="form-control" id="name_url" placeholder="Name Url Here" @required(true)>
                    </div>
                  </div>
                  <div class="col-sm-12 col-md-4">
                    <div class="mb-3">
                      <label for="inputname" class="control-label col-form-label">Name</label>
                      <input type="text" name="name"  @if (isset($user)) value="{{$user->name}}"  @endif class="form-control" id="anme" placeholder="Name Here" @required(true)>
                    </div>
                  </div>
                  
                  <div class="col-sm-12 col-md-4">
                    <div class="mb-3">
                      <label for="inputcontact" class="control-label col-form-label">Phone</label>
                      <input type="text" name="phone"  @if (isset($user)) value="{{$user->phone}}"  @endif class="form-control" id="phone" placeholder="Phone Here">
                    </div>
                  </div>
                </div>
                <div class="row">
                  
                  <div class="col-sm-12 col-md-6">
                    <div class="mb-3">
                      <label for="inputlname" class="control-label col-form-label">Email</label>
                      <input type="email" name="email"  @if (isset($user)) value="{{$user->email}}"  @endif class="form-control" id="inputEmail3" placeholder="Email Here" @required(true)>
                    </div>
                  </div>
                  <div class="col-sm-12 col-md-6">
                    <div class="mb-3">
                      <label for="inputEmail3" class="control-label col-form-label">Password</label>
                      <input type="password" name="password"  @if (!isset($user)) @required(true) @endif class="form-control" id="inputEmail3" placeholder="Password Here" >
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-12 col-md-6">
                    <div class="mb-3">
                      <label for="inputEmail3" class="control-label col-form-label">Expiry Date</label>
                      <input type="date" name="expiry_date"  @if (isset($user)) value="{{$user->expiry_date}}"  @endif class="form-control" id="date" placeholder="Expiry Date Here" @required(true)>
                    </div>
                  </div>
                  <div class="col-sm-12 col-md-6">
                    <div class="mb-3">
                      <label for="inputcontact" class="control-label col-form-label">Notes</label>
                      <input type="text" name="note"  @if (isset($user)) value="{{$user->note}}"  @endif class="form-control" id="note" placeholder="Notes Here">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-12 col-md-6">
                    <div class="mb-3">
                      <label for="inputEmail3" class="control-label col-form-label">Logo</label>
                      <input type="file" name="file"  class="form-control" id="file" placeholder="Notes Here">
                        @if (isset($user)) 
                          <img src="{{$user->logo}}" width="100px" alt="" style="margin-top: 10px">
                        @endif 
                    </div>
                  </div>
                  <div class="col-sm-12 col-md-6">
                    <div class="mb-3">
                      <label for="inputcontact" class="control-label col-form-label">Status</label>
                      <select name="status" id=""  class="col-3 text-end control-label col-form-label form-control" required>
                        <option value="active" @if (isset($user)) @if($user->stauts =='active' ) selected @endif  @endif>Active</option>
                        <option value="inactive" @if (isset($user)) @if($user->stauts =='inactive' ) selected @endif  @endif>Inactive</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div class="action-form">
                  <div class="mb-3 mb-0 text-start">
                    <button type="submit" class="btn btn-info rounded-pill px-4 waves-effect waves-light">
                      Save
                    </button>
                    <a href="{{URL::to('admin/sub_user_list')}}">
                      <button type="button" class="btn btn-dark rounded-pill px-4 waves-effect waves-light">
                        Cancel
                      </button>
                    </a>
                  </div>
                </div>

              </div>
              
            </form>
          </div>

        </div>
    </div>
</div>

@endsection