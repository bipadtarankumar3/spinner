@extends('adminLayouts.home')
@section('content')


<div class="container-fluid">
<!-- basic table -->
<div class="row">
    <div class="col-12">
        <!-- ---------------------
                start Zero Configuration
            ---------------- -->
        <div class="card">
            <div class="card-header">
                <div class="mb-2">
                    <div class="row">
                        <div class="col-md-10">
                            <h5 class="mb-0">Spinner Form List</h5>
                        </div>
                        {{-- <div class="col-md-2">
                            <a href="{{URL::to('admin/add_spinner_page')}}" class="btn btn-info">Add</a>
                        </div> --}}
                    </div>
                    
                    
                </div>
            </div>
            <div class="card-body">
                
                
                <div class="table-responsive">
                    <table id="zero_config"
                        class="table border table-striped table-bordered text-nowrap">
                        <thead>
                            <!-- start row -->
                            <tr>
                                <th>Sl.</th>
                                <th>Date</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Schreenshot</th>
                                <th>IP Address</th>
                                <th>Action</th>
                            </tr>
                            <!-- end row -->
                        </thead>
                        <tbody>

                            @foreach ($SpinnerForm as $key=> $item)
                                <!-- start row -->
                                <tr>
                                    <td>{{$key+1}}</td>
                                    <td>{{$item->created_at}}</td>
                                    <td>{{$item->name}}</td>
                                    <td>{{$item->email}}</td>
                                    <td>{{$item->phone}}</td>
                                    <td style="text-align: center">
                                        <img src="{{$item->schreenshot}}" alt="" width="100px"><br>
                                        <a href="{{$item->schreenshot}}" download="{{$item->name}}">Download</a>
                                    </td>
                                    <td>{{$item->mac_address}}</td>
                                    <td>
                                        <a href="{{URL::to('admin/delete_spinner_form_list/'.$item->id)}}"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                                <!-- end row --> 
                            @endforeach

                            
                            
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
        <!-- ---------------------
                end Zero Configuration
            ---------------- -->
    </div>
</div>
</div>

@endsection


@section('js')
    <script>
        $("#zero_config").DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });
    </script>
@endsection